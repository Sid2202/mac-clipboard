//
//  clipboardApp.swift
//  clipboard
//
//  Created by Sidhanti Patil on 04/05/25.
//

import SwiftUI

@main
struct clipboardApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        // Don't create any visible windows
        Settings { }
    }
}
